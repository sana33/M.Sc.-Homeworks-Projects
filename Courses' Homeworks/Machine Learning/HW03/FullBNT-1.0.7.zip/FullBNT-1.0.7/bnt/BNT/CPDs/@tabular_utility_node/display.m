function display(CPD)

disp('tabular utility node object');
disp(struct(CPD)); 
