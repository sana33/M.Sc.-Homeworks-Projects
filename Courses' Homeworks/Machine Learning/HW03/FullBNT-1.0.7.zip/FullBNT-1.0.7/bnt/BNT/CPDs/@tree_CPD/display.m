function display(CPD)

disp('dtree_CPD object');
disp(struct(CPD)); 
